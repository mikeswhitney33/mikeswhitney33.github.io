
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
	<div class="container">
  <a class="navbar-brand" href="index.php">HOME</a>
  </div>
</nav>
